export declare class MultiselectDropdownModule {
}
