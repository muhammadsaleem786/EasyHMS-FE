import { EventEmitter } from '@angular/core';
export declare class OffClickDirective {
    onOffClick: EventEmitter<any>;
    private _clickEvent;
    private _touchEvent;
    onClick(event: MouseEvent): void;
    onTouch(event: TouchEvent): void;
    onDocumentClick(event: MouseEvent): void;
    onDocumentTouch(event: TouchEvent): void;
}
